#include <stdio.h>
#include <stdlib.h>
#include "record_structure.h"

void read_details(char* id, char* name, int* marks) {
	
}
void validate_id(char* id) {

}
void validate_name(char* name) {

}
void validate_marks(int* marks) {

}
