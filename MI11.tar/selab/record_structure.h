#ifndef INFO_H
#define INFO_H

#define MAX_SUBJECTS 5
#define MAX_STUDENTS 100

typedef struct {
	char roll_number[10];
	char name[30];
	int marks[2 * MAX_SUBJECTS];
}STUDENT;

#endif
