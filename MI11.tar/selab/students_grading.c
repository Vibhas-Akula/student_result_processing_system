#include <stdio.h>
#include <stdlib.h>
#include "record_structure.h"


