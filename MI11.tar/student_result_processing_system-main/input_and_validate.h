#ifndef READ_H
#define READ_H

void read_details(char* id, char* name, int* marks);
int validate_id(char* id);
int validate_name(char* name);
int validate_marks(int* marks);

#endif

