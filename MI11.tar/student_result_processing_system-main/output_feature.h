#ifndef OP_H
#define OP_H

float class_average();
float lowest_percentage();
float highest_percentage();
void grade_category_counts();
void display_report(char* output_file);

#endif