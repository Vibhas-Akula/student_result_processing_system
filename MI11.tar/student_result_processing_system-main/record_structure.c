#include "record_structure.h"

STUDENT student_records[100];
int count = 0;
float percentages[100] = {0.0f};
int grade_counts[8][5] = {0};