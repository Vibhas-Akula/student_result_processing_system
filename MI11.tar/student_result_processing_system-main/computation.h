#ifndef COMPUTE_H
#define COMPUTE_H

void compute_percentages();
void compute_grades();
void compute_cgpa();

#endif

